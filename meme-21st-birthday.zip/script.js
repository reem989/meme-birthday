const openBtn = document.getElementById("openBtn");
const letter = document.getElementById("letter");

openBtn.addEventListener("click", () => {
  letter.scrollIntoView({ behavior: "smooth" });
  burstHearts();
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add("show");
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

function createHeart() {
  const heart = document.createElement("div");
  heart.className = "heart";
  heart.textContent = Math.random() > .5 ? "♡" : "✦";
  heart.style.left = Math.random() * 100 + "vw";
  heart.style.fontSize = (12 + Math.random() * 18) + "px";
  heart.style.animationDuration = (5 + Math.random() * 5) + "s";
  document.body.appendChild(heart);
  setTimeout(() => heart.remove(), 10000);
}

setInterval(createHeart, 1400);

function burstHearts() {
  for (let i = 0; i < 18; i++) {
    setTimeout(createHeart, i * 90);
  }
}
